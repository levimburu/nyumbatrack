
  # Design NyumbaTrack Property Management App

  This is a code bundle for Design NyumbaTrack Property Management App. The original project is available at https://www.figma.com/design/6oVVJIeChUdXjlD4AUOpRO/Design-NyumbaTrack-Property-Management-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  