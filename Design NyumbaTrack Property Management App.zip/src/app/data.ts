export interface Property {
  id: string;
  name: string;
  location: string;
  address: string;
  totalUnits: number;
  occupiedUnits: number;
}

export interface Tenant {
  id: string;
  propertyId: string;
  name: string;
  unit: string;
  phone: string;
  rent: number;
  deposit: number;
  balance: number;
  moveInDate: string;
  nextDueDate: string;
  advanceMonths: number;
  status: 'paid' | 'partial' | 'unpaid';
}

export interface Payment {
  id: string;
  tenantId: string;
  propertyId: string;
  tenantName: string;
  unit: string;
  date: string;
  amount: number;
  monthPaid: string;
  method: 'M-Pesa' | 'Bank Transfer' | 'Cash';
  reference: string;
}

export const properties: Property[] = [
  {
    id: 'prop-1',
    name: 'Sunset Apartments',
    location: 'Kilimani, Nairobi',
    address: 'Milimani Road, Kilimani',
    totalUnits: 12,
    occupiedUnits: 10,
  },
  {
    id: 'prop-2',
    name: 'Green Valley Residences',
    location: 'Westlands, Nairobi',
    address: 'Ring Road, Westlands',
    totalUnits: 8,
    occupiedUnits: 7,
  },
  {
    id: 'prop-3',
    name: 'Nairobi Heights',
    location: 'Upper Hill, Nairobi',
    address: 'Upper Hill Road',
    totalUnits: 6,
    occupiedUnits: 6,
  },
];

export const tenants: Tenant[] = [
  { id: 't1', propertyId: 'prop-1', name: 'John Kamau', unit: '3A', phone: '+254 722 123 456', rent: 45000, deposit: 90000, balance: 0, moveInDate: '2022-03-01', nextDueDate: '2024-07-01', advanceMonths: 2, status: 'paid' },
  { id: 't2', propertyId: 'prop-1', name: 'Mary Wanjiku', unit: '1B', phone: '+254 733 234 567', rent: 38000, deposit: 76000, balance: -19000, moveInDate: '2021-07-15', nextDueDate: '2024-07-01', advanceMonths: 0, status: 'partial' },
  { id: 't3', propertyId: 'prop-1', name: 'Peter Otieno', unit: '2C', phone: '+254 711 345 678', rent: 42000, deposit: 84000, balance: -42000, moveInDate: '2023-01-10', nextDueDate: '2024-06-01', advanceMonths: 0, status: 'unpaid' },
  { id: 't4', propertyId: 'prop-1', name: 'Grace Njeri', unit: '4A', phone: '+254 700 456 789', rent: 50000, deposit: 100000, balance: 0, moveInDate: '2022-09-01', nextDueDate: '2024-07-01', advanceMonths: 1, status: 'paid' },
  { id: 't5', propertyId: 'prop-1', name: 'David Ochieng', unit: '2A', phone: '+254 790 567 890', rent: 45000, deposit: 90000, balance: -45000, moveInDate: '2023-05-01', nextDueDate: '2024-06-01', advanceMonths: 0, status: 'unpaid' },
  { id: 't6', propertyId: 'prop-2', name: 'Sarah Achieng', unit: '1A', phone: '+254 722 678 901', rent: 55000, deposit: 110000, balance: -27500, moveInDate: '2022-11-01', nextDueDate: '2024-07-01', advanceMonths: 0, status: 'partial' },
  { id: 't7', propertyId: 'prop-2', name: 'Michael Kariuki', unit: '2B', phone: '+254 733 789 012', rent: 55000, deposit: 110000, balance: 0, moveInDate: '2021-04-01', nextDueDate: '2024-07-01', advanceMonths: 3, status: 'paid' },
  { id: 't8', propertyId: 'prop-3', name: 'Jane Waweru', unit: '1A', phone: '+254 711 890 123', rent: 65000, deposit: 130000, balance: -65000, moveInDate: '2023-08-01', nextDueDate: '2024-06-01', advanceMonths: 0, status: 'unpaid' },
  { id: 't9', propertyId: 'prop-3', name: 'Robert Mwangi', unit: '2B', phone: '+254 700 901 234', rent: 65000, deposit: 130000, balance: 0, moveInDate: '2022-06-01', nextDueDate: '2024-07-01', advanceMonths: 1, status: 'paid' },
];

export const payments: Payment[] = [
  { id: 'p1', tenantId: 't1', propertyId: 'prop-1', tenantName: 'John Kamau', unit: '3A', date: '2024-06-01', amount: 45000, monthPaid: 'June 2024', method: 'M-Pesa', reference: 'QCA5H3K8JL' },
  { id: 'p2', tenantId: 't4', propertyId: 'prop-1', tenantName: 'Grace Njeri', unit: '4A', date: '2024-06-02', amount: 50000, monthPaid: 'June 2024', method: 'M-Pesa', reference: 'RBD6I4L9KM' },
  { id: 'p3', tenantId: 't2', propertyId: 'prop-1', tenantName: 'Mary Wanjiku', unit: '1B', date: '2024-06-05', amount: 19000, monthPaid: 'June 2024', method: 'Bank Transfer', reference: 'TXN-2024-0605-MW' },
  { id: 'p4', tenantId: 't7', propertyId: 'prop-2', tenantName: 'Michael Kariuki', unit: '2B', date: '2024-06-01', amount: 55000, monthPaid: 'June 2024', method: 'M-Pesa', reference: 'SCE7J5M0LN' },
  { id: 'p5', tenantId: 't1', propertyId: 'prop-1', tenantName: 'John Kamau', unit: '3A', date: '2024-05-01', amount: 45000, monthPaid: 'May 2024', method: 'M-Pesa', reference: 'PBB4G2J7IK' },
  { id: 'p6', tenantId: 't4', propertyId: 'prop-1', tenantName: 'Grace Njeri', unit: '4A', date: '2024-05-03', amount: 50000, monthPaid: 'May 2024', method: 'M-Pesa', reference: 'QCD5H3K8JL' },
  { id: 'p7', tenantId: 't2', propertyId: 'prop-1', tenantName: 'Mary Wanjiku', unit: '1B', date: '2024-05-08', amount: 38000, monthPaid: 'May 2024', method: 'Cash', reference: 'CASH-MAY-2024-MW' },
  { id: 'p8', tenantId: 't3', propertyId: 'prop-1', tenantName: 'Peter Otieno', unit: '2C', date: '2024-05-15', amount: 42000, monthPaid: 'May 2024', method: 'M-Pesa', reference: 'RBD7I4L0KM' },
  { id: 'p9', tenantId: 't9', propertyId: 'prop-3', tenantName: 'Robert Mwangi', unit: '2B', date: '2024-06-01', amount: 65000, monthPaid: 'June 2024', method: 'Bank Transfer', reference: 'TXN-2024-0601-RM' },
  { id: 'p10', tenantId: 't6', propertyId: 'prop-2', tenantName: 'Sarah Achieng', unit: '1A', date: '2024-06-10', amount: 27500, monthPaid: 'June 2024', method: 'M-Pesa', reference: 'SCF8K6N1MO' },
];

export const monthlyIncome = [
  { month: 'Jan', amount: 385000 },
  { month: 'Feb', amount: 402000 },
  { month: 'Mar', amount: 375000 },
  { month: 'Apr', amount: 428000 },
  { month: 'May', amount: 455000 },
  { month: 'Jun', amount: 301500 },
];

export const fmt = (n: number) => `KSh ${n.toLocaleString('en-KE')}`;
