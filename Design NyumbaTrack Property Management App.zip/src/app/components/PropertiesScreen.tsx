import { Building2, MapPin, Users, TrendingUp, Plus, UserPlus, ChevronRight, Percent } from 'lucide-react';
import { properties, tenants, fmt } from '../data';

interface PropertiesScreenProps {
  onSelectProperty: (id: string) => void;
}

export function PropertiesScreen({ onSelectProperty }: PropertiesScreenProps) {
  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-foreground">My Properties</h1>
          <p className="text-sm" style={{ color: '#6B7A6E' }}>{properties.length} properties managed</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm border transition-colors"
            style={{ borderColor: 'rgba(0,0,0,0.12)', color: '#1A2E1F' }}
            onMouseOver={e => (e.currentTarget.style.backgroundColor = '#EEF1EE')}
            onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
          >
            <UserPlus className="w-4 h-4" />
            <span className="hidden sm:inline" style={{ fontWeight: 500 }}>Invite Agent</span>
          </button>
          <button
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm text-white transition-colors"
            style={{ backgroundColor: '#1A5C3A', fontWeight: 500 }}
            onMouseOver={e => (e.currentTarget.style.backgroundColor = '#155030')}
            onMouseOut={e => (e.currentTarget.style.backgroundColor = '#1A5C3A')}
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Add Property</span>
          </button>
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {properties.map(property => {
          const propTenants = tenants.filter(t => t.propertyId === property.id);
          const monthlyExpected = propTenants.reduce((sum, t) => sum + t.rent, 0);
          const occupancyRate = Math.round((property.occupiedUnits / property.totalUnits) * 100);
          const paid = propTenants.filter(t => t.status === 'paid').length;
          const partial = propTenants.filter(t => t.status === 'partial').length;
          const unpaid = propTenants.filter(t => t.status === 'unpaid').length;

          return (
            <button
              key={property.id}
              onClick={() => onSelectProperty(property.id)}
              className="bg-card rounded-2xl text-left transition-all group overflow-hidden"
              style={{
                border: '1px solid rgba(0,0,0,0.07)',
                boxShadow: '0 1px 6px rgba(0,0,0,0.06)',
              }}
              onMouseOver={e => {
                e.currentTarget.style.boxShadow = '0 6px 24px rgba(26,92,58,0.12)';
                e.currentTarget.style.borderColor = 'rgba(26,92,58,0.25)';
              }}
              onMouseOut={e => {
                e.currentTarget.style.boxShadow = '0 1px 6px rgba(0,0,0,0.06)';
                e.currentTarget.style.borderColor = 'rgba(0,0,0,0.07)';
              }}
            >
              {/* Image strip */}
              <div
                className="w-full h-32 flex items-center justify-center relative"
                style={{ background: 'linear-gradient(135deg, #1A5C3A 0%, #0D3B2A 100%)' }}
              >
                <Building2 className="w-14 h-14" style={{ color: 'rgba(255,255,255,0.18)' }} />
                {/* Occupancy badge */}
                <div
                  className="absolute top-3 right-3 px-2.5 py-1 rounded-full text-xs"
                  style={{
                    backgroundColor: 'rgba(255,255,255,0.18)',
                    color: '#ffffff',
                    fontWeight: 600,
                    backdropFilter: 'blur(8px)',
                  }}
                >
                  {occupancyRate}% occupied
                </div>
                {/* Unit count */}
                <div
                  className="absolute bottom-3 left-3 px-2.5 py-1 rounded-full text-xs flex items-center gap-1"
                  style={{ backgroundColor: 'rgba(212,144,10,0.9)', color: '#ffffff', fontWeight: 600 }}
                >
                  <Users className="w-3 h-3" />
                  {property.occupiedUnits}/{property.totalUnits} units
                </div>
              </div>

              {/* Info */}
              <div className="p-5">
                <h3
                  className="mb-1 transition-colors"
                  style={{ color: '#1A2E1F', fontWeight: 600, fontSize: '16px' }}
                >
                  {property.name}
                </h3>
                <div className="flex items-center gap-1 mb-4" style={{ color: '#6B7A6E' }}>
                  <MapPin className="w-3.5 h-3.5 flex-shrink-0" />
                  <span className="text-sm">{property.location}</span>
                </div>

                {/* Stats row */}
                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="rounded-xl p-3" style={{ backgroundColor: '#F5F3EF' }}>
                    <div className="flex items-center gap-1.5 mb-1">
                      <TrendingUp className="w-3.5 h-3.5" style={{ color: '#6B7A6E' }} />
                      <span className="text-xs" style={{ color: '#6B7A6E' }}>Monthly Rent</span>
                    </div>
                    <span className="text-sm" style={{ color: '#1A2E1F', fontWeight: 600 }}>{fmt(monthlyExpected)}</span>
                  </div>
                  <div className="rounded-xl p-3" style={{ backgroundColor: '#F5F3EF' }}>
                    <div className="flex items-center gap-1.5 mb-1">
                      <Percent className="w-3.5 h-3.5" style={{ color: '#6B7A6E' }} />
                      <span className="text-xs" style={{ color: '#6B7A6E' }}>Occupancy</span>
                    </div>
                    <span className="text-sm" style={{ color: '#1A2E1F', fontWeight: 600 }}>{occupancyRate}%</span>
                  </div>
                </div>

                {/* Tenant status pills */}
                <div className="flex items-center gap-2 mb-3">
                  {paid > 0 && (
                    <span className="px-2 py-0.5 rounded-full text-xs" style={{ backgroundColor: '#dcfce7', color: '#15803d', fontWeight: 500 }}>
                      {paid} paid
                    </span>
                  )}
                  {partial > 0 && (
                    <span className="px-2 py-0.5 rounded-full text-xs" style={{ backgroundColor: '#fef3c7', color: '#b45309', fontWeight: 500 }}>
                      {partial} partial
                    </span>
                  )}
                  {unpaid > 0 && (
                    <span className="px-2 py-0.5 rounded-full text-xs" style={{ backgroundColor: '#fee2e2', color: '#b91c1c', fontWeight: 500 }}>
                      {unpaid} unpaid
                    </span>
                  )}
                </div>

                <div className="flex items-center justify-end text-sm" style={{ color: '#1A5C3A', fontWeight: 600 }}>
                  View Dashboard <ChevronRight className="w-4 h-4 ml-1" />
                </div>
              </div>
            </button>
          );
        })}

        {/* Add property placeholder */}
        <button
          className="rounded-2xl p-5 flex flex-col items-center justify-center min-h-[260px] text-center transition-all group"
          style={{
            border: '2px dashed rgba(0,0,0,0.12)',
            backgroundColor: 'transparent',
          }}
          onMouseOver={e => {
            e.currentTarget.style.borderColor = 'rgba(26,92,58,0.4)';
            e.currentTarget.style.backgroundColor = 'rgba(26,92,58,0.03)';
          }}
          onMouseOut={e => {
            e.currentTarget.style.borderColor = 'rgba(0,0,0,0.12)';
            e.currentTarget.style.backgroundColor = 'transparent';
          }}
        >
          <div className="w-12 h-12 rounded-full flex items-center justify-center mb-3 transition-colors" style={{ backgroundColor: '#EEF1EE' }}>
            <Plus className="w-6 h-6" style={{ color: '#6B7A6E' }} />
          </div>
          <p className="text-sm" style={{ color: '#6B7A6E', fontWeight: 500 }}>Add New Property</p>
          <p className="text-xs mt-1" style={{ color: '#9CA3AF' }}>Register a property to get started</p>
        </button>
      </div>
    </div>
  );
}
