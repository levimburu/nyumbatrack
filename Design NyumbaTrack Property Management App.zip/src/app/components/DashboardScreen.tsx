import { Users, TrendingUp, CheckCircle, AlertCircle } from 'lucide-react';
import { properties, tenants, payments, fmt } from '../data';

type SubPage = 'tenants' | 'payments';

interface DashboardScreenProps {
  propertyId: string;
  onNavigate: (page: SubPage) => void;
}

const STATUS_CONFIG = {
  paid: { label: 'Paid', bg: '#dcfce7', text: '#15803d' },
  partial: { label: 'Partial', bg: '#fef3c7', text: '#b45309' },
  unpaid: { label: 'Unpaid', bg: '#fee2e2', text: '#b91c1c' },
};

export function DashboardScreen({ propertyId, onNavigate }: DashboardScreenProps) {
  const property = properties.find(p => p.id === propertyId)!;
  const propTenants = tenants.filter(t => t.propertyId === propertyId);
  const propPayments = payments.filter(p => p.propertyId === propertyId).slice(0, 5);

  const expectedRent = propTenants.reduce((sum, t) => sum + t.rent, 0);
  const collected = propTenants.reduce((sum, t) => {
    if (t.status === 'paid') return sum + t.rent;
    if (t.status === 'partial') return sum + (t.rent + t.balance);
    return sum;
  }, 0);
  const outstanding = expectedRent - collected;

  const statCards = [
    { label: 'Total Tenants', value: String(propTenants.length), Icon: Users, bg: '#EFF6FF', iconColor: '#2563EB' },
    { label: 'Expected Rent', value: fmt(expectedRent), Icon: TrendingUp, bg: '#FFFBEB', iconColor: '#D97706' },
    { label: 'Collected', value: fmt(collected), Icon: CheckCircle, bg: '#F0FDF4', iconColor: '#16A34A' },
    { label: 'Outstanding', value: fmt(outstanding), Icon: AlertCircle, bg: '#FEF2F2', iconColor: '#DC2626' },
  ];

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="mb-6">
        <h1 className="text-foreground">{property.name}</h1>
        <p className="text-sm" style={{ color: '#6B7A6E' }}>{property.location}</p>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4 mb-6">
        {statCards.map(({ label, value, Icon, bg, iconColor }) => (
          <div
            key={label}
            className="bg-card rounded-2xl p-4 md:p-5"
            style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 6px rgba(0,0,0,0.04)' }}
          >
            <div
              className="w-10 h-10 rounded-xl flex items-center justify-center mb-3"
              style={{ backgroundColor: bg }}
            >
              <Icon className="w-5 h-5" style={{ color: iconColor }} />
            </div>
            <p className="text-xs mb-1" style={{ color: '#6B7A6E' }}>{label}</p>
            <p className="leading-tight" style={{ color: '#1A2E1F', fontWeight: 700, fontSize: '15px' }}>{value}</p>
          </div>
        ))}
      </div>

      {/* Two-column section */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {/* Tenants overview table */}
        <div
          className="lg:col-span-3 bg-card rounded-2xl overflow-hidden"
          style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 6px rgba(0,0,0,0.04)' }}
        >
          <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
            <h3 style={{ color: '#1A2E1F', fontWeight: 600 }}>Tenant Overview</h3>
            <button
              onClick={() => onNavigate('tenants')}
              className="text-sm transition-colors"
              style={{ color: '#1A5C3A', fontWeight: 500 }}
              onMouseOver={e => (e.currentTarget.style.textDecoration = 'underline')}
              onMouseOut={e => (e.currentTarget.style.textDecoration = 'none')}
            >
              View all
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr style={{ backgroundColor: 'rgba(0,0,0,0.025)' }}>
                  {['Tenant', 'Unit', 'Rent', 'Status'].map(h => (
                    <th key={h} className="px-5 py-3 text-left text-xs" style={{ color: '#6B7A6E', fontWeight: 500 }}>
                      {h}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {propTenants.slice(0, 5).map((tenant, idx) => {
                  const s = STATUS_CONFIG[tenant.status];
                  return (
                    <tr
                      key={tenant.id}
                      style={{ borderTop: idx > 0 ? '1px solid rgba(0,0,0,0.05)' : 'none' }}
                      onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.02)')}
                      onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                    >
                      <td className="px-5 py-3.5">
                        <div className="flex items-center gap-3">
                          <div
                            className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                            style={{ backgroundColor: 'rgba(26,92,58,0.1)' }}
                          >
                            <span className="text-xs" style={{ color: '#1A5C3A', fontWeight: 600 }}>{tenant.name.charAt(0)}</span>
                          </div>
                          <span className="text-sm" style={{ color: '#1A2E1F', fontWeight: 500 }}>{tenant.name}</span>
                        </div>
                      </td>
                      <td className="px-5 py-3.5 text-sm font-mono" style={{ color: '#6B7A6E' }}>{tenant.unit}</td>
                      <td className="px-5 py-3.5 text-sm" style={{ color: '#1A2E1F' }}>{fmt(tenant.rent)}</td>
                      <td className="px-5 py-3.5">
                        <span
                          className="inline-flex px-2.5 py-1 rounded-full text-xs"
                          style={{ backgroundColor: s.bg, color: s.text, fontWeight: 500 }}
                        >
                          {s.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Recent payments feed */}
        <div
          className="lg:col-span-2 bg-card rounded-2xl overflow-hidden"
          style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 6px rgba(0,0,0,0.04)' }}
        >
          <div className="flex items-center justify-between px-5 py-4" style={{ borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
            <h3 style={{ color: '#1A2E1F', fontWeight: 600 }}>Recent Payments</h3>
            <button
              onClick={() => onNavigate('payments')}
              className="text-sm"
              style={{ color: '#1A5C3A', fontWeight: 500 }}
              onMouseOver={e => (e.currentTarget.style.textDecoration = 'underline')}
              onMouseOut={e => (e.currentTarget.style.textDecoration = 'none')}
            >
              View all
            </button>
          </div>
          <div>
            {propPayments.length === 0 && (
              <p className="px-5 py-8 text-sm text-center" style={{ color: '#6B7A6E' }}>No payments yet</p>
            )}
            {propPayments.map((payment, idx) => (
              <div
                key={payment.id}
                className="px-5 py-3.5 flex items-center gap-3"
                style={{ borderTop: idx > 0 ? '1px solid rgba(0,0,0,0.05)' : 'none' }}
                onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.02)')}
                onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
              >
                <div
                  className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                  style={{ backgroundColor: '#f0fdf4' }}
                >
                  <CheckCircle className="w-4 h-4" style={{ color: '#16a34a' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm truncate" style={{ color: '#1A2E1F', fontWeight: 500 }}>{payment.tenantName}</p>
                  <p className="text-xs" style={{ color: '#6B7A6E' }}>{payment.monthPaid}</p>
                </div>
                <span className="text-sm flex-shrink-0" style={{ color: '#16a34a', fontWeight: 600 }}>+{fmt(payment.amount)}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
