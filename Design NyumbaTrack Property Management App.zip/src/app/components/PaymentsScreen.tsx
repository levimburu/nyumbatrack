import { useState } from 'react';
import { Plus, Receipt, Search, Download, X } from 'lucide-react';
import * as Dialog from '@radix-ui/react-dialog';
import { payments, tenants, properties, fmt } from '../data';

interface PaymentsScreenProps {
  propertyId: string;
}

export function PaymentsScreen({ propertyId }: PaymentsScreenProps) {
  const [selectedPaymentId, setSelectedPaymentId] = useState<string | null>(null);
  const [showRecordModal, setShowRecordModal] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const property = properties.find(p => p.id === propertyId)!;
  const propPayments = payments
    .filter(p => p.propertyId === propertyId)
    .filter(p =>
      searchQuery === '' ||
      p.tenantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      p.reference.toLowerCase().includes(searchQuery.toLowerCase())
    );

  const selectedPayment = payments.find(p => p.id === selectedPaymentId);
  const totalCollected = propPayments.reduce((sum, p) => sum + p.amount, 0);
  const propTenants = tenants.filter(t => t.propertyId === propertyId);

  const methodStyle = (method: string) => ({
    bg: method === 'M-Pesa' ? '#dcfce7' : method === 'Bank Transfer' ? '#dbeafe' : '#f3f4f6',
    color: method === 'M-Pesa' ? '#15803d' : method === 'Bank Transfer' ? '#1d4ed8' : '#374151',
  });

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-foreground">Payments</h1>
          <p className="text-sm" style={{ color: '#6B7A6E' }}>
            {property.name} · {propPayments.length} records · Total {fmt(totalCollected)}
          </p>
        </div>
        <button
          onClick={() => setShowRecordModal(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm text-white transition-colors"
          style={{ backgroundColor: '#1A5C3A', fontWeight: 500 }}
          onMouseOver={e => (e.currentTarget.style.backgroundColor = '#155030')}
          onMouseOut={e => (e.currentTarget.style.backgroundColor = '#1A5C3A')}
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Record Payment</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#6B7A6E' }} />
        <input
          type="text"
          placeholder="Search by tenant or reference..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl text-sm outline-none bg-card"
          style={{ border: '1px solid rgba(0,0,0,0.1)', color: '#1A2E1F' }}
          onFocus={e => {
            e.currentTarget.style.borderColor = '#1A5C3A';
            e.currentTarget.style.boxShadow = '0 0 0 3px rgba(26,92,58,0.1)';
          }}
          onBlur={e => {
            e.currentTarget.style.borderColor = 'rgba(0,0,0,0.1)';
            e.currentTarget.style.boxShadow = 'none';
          }}
        />
      </div>

      {/* Desktop table */}
      <div
        className="hidden md:block bg-card rounded-2xl overflow-hidden"
        style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 6px rgba(0,0,0,0.04)' }}
      >
        <table className="w-full">
          <thead>
            <tr style={{ backgroundColor: 'rgba(0,0,0,0.025)' }}>
              {['Date', 'Tenant', 'Unit', 'Month Paid', 'Method', 'Reference', 'Amount', 'Receipt'].map(h => (
                <th key={h} className="px-4 py-3 text-left text-xs" style={{ color: '#6B7A6E', fontWeight: 500, borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {propPayments.map((payment, idx) => {
              const ms = methodStyle(payment.method);
              return (
                <tr
                  key={payment.id}
                  style={{ borderTop: idx > 0 ? '1px solid rgba(0,0,0,0.05)' : 'none' }}
                  onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.02)')}
                  onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                >
                  <td className="px-4 py-3.5 text-sm" style={{ color: '#6B7A6E' }}>{payment.date}</td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-2">
                      <div
                        className="w-7 h-7 rounded-full flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: 'rgba(26,92,58,0.1)' }}
                      >
                        <span className="text-xs" style={{ color: '#1A5C3A', fontWeight: 600 }}>{payment.tenantName.charAt(0)}</span>
                      </div>
                      <span className="text-sm" style={{ color: '#1A2E1F', fontWeight: 500 }}>{payment.tenantName}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5 text-sm font-mono" style={{ color: '#6B7A6E' }}>{payment.unit}</td>
                  <td className="px-4 py-3.5 text-sm" style={{ color: '#1A2E1F' }}>{payment.monthPaid}</td>
                  <td className="px-4 py-3.5">
                    <span className="inline-flex px-2 py-0.5 rounded-full text-xs" style={{ backgroundColor: ms.bg, color: ms.color, fontWeight: 500 }}>
                      {payment.method}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-xs font-mono" style={{ color: '#6B7A6E' }}>{payment.reference}</td>
                  <td className="px-4 py-3.5 text-sm" style={{ color: '#16a34a', fontWeight: 600 }}>{fmt(payment.amount)}</td>
                  <td className="px-4 py-3.5">
                    <button
                      onClick={() => setSelectedPaymentId(payment.id)}
                      className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
                      onMouseOver={e => (e.currentTarget.style.backgroundColor = '#EEF1EE')}
                      onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                    >
                      <Receipt className="w-4 h-4" style={{ color: '#6B7A6E' }} />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-3">
        {propPayments.map(payment => {
          const ms = methodStyle(payment.method);
          return (
            <div
              key={payment.id}
              className="bg-card rounded-2xl p-4"
              style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div
                    className="w-8 h-8 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: 'rgba(26,92,58,0.1)' }}
                  >
                    <span className="text-xs" style={{ color: '#1A5C3A', fontWeight: 600 }}>{payment.tenantName.charAt(0)}</span>
                  </div>
                  <div>
                    <p className="text-sm" style={{ color: '#1A2E1F', fontWeight: 600 }}>{payment.tenantName}</p>
                    <p className="text-xs" style={{ color: '#6B7A6E' }}>Unit {payment.unit}</p>
                  </div>
                </div>
                <span className="text-sm" style={{ color: '#16a34a', fontWeight: 700 }}>{fmt(payment.amount)}</span>
              </div>
              <div className="flex items-center justify-between text-xs" style={{ color: '#6B7A6E' }}>
                <span>{payment.date} · {payment.monthPaid}</span>
                <div className="flex items-center gap-2">
                  <span className="px-2 py-0.5 rounded-full" style={{ backgroundColor: ms.bg, color: ms.color, fontWeight: 500 }}>
                    {payment.method}
                  </span>
                  <button onClick={() => setSelectedPaymentId(payment.id)}>
                    <Receipt className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Receipt modal */}
      {selectedPayment && (
        <Dialog.Root open onOpenChange={open => !open && setSelectedPaymentId(null)}>
          <Dialog.Portal>
            <Dialog.Overlay className="fixed inset-0 z-50" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} />
            <Dialog.Content
              className="fixed top-1/2 left-1/2 w-full max-w-sm bg-white rounded-2xl z-50 overflow-hidden"
              style={{ transform: 'translate(-50%, -50%)', boxShadow: '0 25px 60px rgba(0,0,0,0.25)' }}
            >
              <div className="p-5" style={{ backgroundColor: '#1A5C3A' }}>
                <div className="flex items-center justify-between mb-5">
                  <div className="flex items-center gap-2">
                    <Receipt className="w-5 h-5" style={{ color: '#D4900A' }} />
                    <span className="text-white" style={{ fontWeight: 600 }}>Payment Receipt</span>
                  </div>
                  <Dialog.Close asChild>
                    <button
                      className="w-7 h-7 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: 'rgba(255,255,255,0.12)' }}
                    >
                      <X className="w-4 h-4 text-white" />
                    </button>
                  </Dialog.Close>
                </div>
                <div className="text-center">
                  <p style={{ color: 'rgba(255,255,255,0.6)', fontSize: '13px' }}>Amount Paid</p>
                  <p className="text-white" style={{ fontSize: '32px', fontWeight: 700, marginTop: '4px' }}>
                    {fmt(selectedPayment.amount)}
                  </p>
                  <span
                    className="inline-flex mt-2 px-3 py-1 rounded-full text-xs"
                    style={{ backgroundColor: '#D4900A', color: '#fff', fontWeight: 600 }}
                  >
                    {selectedPayment.method}
                  </span>
                </div>
              </div>
              <div className="p-5 space-y-0">
                {[
                  ['Tenant', selectedPayment.tenantName],
                  ['Unit', selectedPayment.unit],
                  ['Month Paid', selectedPayment.monthPaid],
                  ['Payment Date', selectedPayment.date],
                  ['Reference', selectedPayment.reference],
                  ['Property', property.name],
                ].map(([label, value], i) => (
                  <div
                    key={label}
                    className="flex justify-between items-center py-3"
                    style={{ borderBottom: i < 5 ? '1px solid rgba(0,0,0,0.06)' : 'none' }}
                  >
                    <span className="text-sm" style={{ color: '#6B7A6E' }}>{label}</span>
                    <span className="text-sm" style={{ color: '#1A2E1F', fontWeight: 500 }}>{value}</span>
                  </div>
                ))}
                <button
                  className="w-full mt-4 py-3 rounded-xl flex items-center justify-center gap-2 text-sm text-white transition-colors"
                  style={{ backgroundColor: '#1A5C3A', fontWeight: 500 }}
                  onMouseOver={e => (e.currentTarget.style.backgroundColor = '#155030')}
                  onMouseOut={e => (e.currentTarget.style.backgroundColor = '#1A5C3A')}
                >
                  <Download className="w-4 h-4" />
                  Download Receipt
                </button>
              </div>
            </Dialog.Content>
          </Dialog.Portal>
        </Dialog.Root>
      )}

      {/* Record payment modal */}
      {showRecordModal && (
        <Dialog.Root open onOpenChange={open => !open && setShowRecordModal(false)}>
          <Dialog.Portal>
            <Dialog.Overlay className="fixed inset-0 z-50" style={{ backgroundColor: 'rgba(0,0,0,0.5)' }} />
            <Dialog.Content
              className="fixed top-1/2 left-1/2 w-full max-w-md bg-background rounded-2xl z-50 p-6"
              style={{ transform: 'translate(-50%, -50%)', boxShadow: '0 25px 60px rgba(0,0,0,0.2)' }}
            >
              <div className="flex items-center justify-between mb-5">
                <Dialog.Title style={{ color: '#1A2E1F', fontWeight: 600, fontSize: '18px' }}>Record Payment</Dialog.Title>
                <Dialog.Close asChild>
                  <button
                    className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
                    onMouseOver={e => (e.currentTarget.style.backgroundColor = '#EEF1EE')}
                    onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                  >
                    <X className="w-4 h-4" style={{ color: '#6B7A6E' }} />
                  </button>
                </Dialog.Close>
              </div>
              <div className="space-y-4">
                {[
                  { label: 'Tenant', type: 'select', options: propTenants.map(t => ({ value: t.id, label: `${t.name} – Unit ${t.unit}` })) },
                  { label: 'Amount (KSh)', type: 'number', placeholder: '45000' },
                  { label: 'Payment Method', type: 'select', options: [{ value: 'M-Pesa', label: 'M-Pesa' }, { value: 'Bank Transfer', label: 'Bank Transfer' }, { value: 'Cash', label: 'Cash' }] },
                  { label: 'Reference / Transaction Code', type: 'text', placeholder: 'e.g. QCA5H3K8JL' },
                  { label: 'Month Paid', type: 'text', placeholder: 'e.g. June 2024' },
                ].map(field => (
                  <div key={field.label}>
                    <label className="text-sm mb-1.5 block" style={{ color: '#6B7A6E' }}>{field.label}</label>
                    {field.type === 'select' ? (
                      <select
                        className="w-full px-3 py-2.5 rounded-xl text-sm outline-none bg-card"
                        style={{ border: '1px solid rgba(0,0,0,0.1)', color: '#1A2E1F' }}
                      >
                        {field.options?.map(opt => (
                          <option key={opt.value} value={opt.value}>{opt.label}</option>
                        ))}
                      </select>
                    ) : (
                      <input
                        type={field.type}
                        placeholder={field.placeholder}
                        className="w-full px-3 py-2.5 rounded-xl text-sm outline-none bg-card"
                        style={{ border: '1px solid rgba(0,0,0,0.1)', color: '#1A2E1F' }}
                        onFocus={e => {
                          e.currentTarget.style.borderColor = '#1A5C3A';
                          e.currentTarget.style.boxShadow = '0 0 0 3px rgba(26,92,58,0.1)';
                        }}
                        onBlur={e => {
                          e.currentTarget.style.borderColor = 'rgba(0,0,0,0.1)';
                          e.currentTarget.style.boxShadow = 'none';
                        }}
                      />
                    )}
                  </div>
                ))}
                <button
                  onClick={() => setShowRecordModal(false)}
                  className="w-full py-3 rounded-xl text-sm text-white transition-colors"
                  style={{ backgroundColor: '#1A5C3A', fontWeight: 500, marginTop: '8px' }}
                  onMouseOver={e => (e.currentTarget.style.backgroundColor = '#155030')}
                  onMouseOut={e => (e.currentTarget.style.backgroundColor = '#1A5C3A')}
                >
                  Record Payment
                </button>
              </div>
            </Dialog.Content>
          </Dialog.Portal>
        </Dialog.Root>
      )}
    </div>
  );
}
