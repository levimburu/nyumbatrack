import * as Dialog from '@radix-ui/react-dialog';
import { X, Calendar, DollarSign, Home, Clock, Phone } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from 'recharts';
import { type Tenant, payments, fmt } from '../data';

interface TenantProfileModalProps {
  tenant: Tenant;
  onClose: () => void;
}

const STATUS_CONFIG = {
  paid: { label: 'Paid', bg: '#dcfce7', text: '#15803d' },
  partial: { label: 'Partial', bg: '#fef3c7', text: '#b45309' },
  unpaid: { label: 'Unpaid', bg: '#fee2e2', text: '#b91c1c' },
};

const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'];

export function TenantProfileModal({ tenant, onClose }: TenantProfileModalProps) {
  const tenantPayments = payments.filter(p => p.tenantId === tenant.id);
  const s = STATUS_CONFIG[tenant.status];

  const chartData = MONTHS.map((month, i) => {
    const paid = i === 4 ? (tenant.status !== 'unpaid' ? tenant.rent : 0) : 0;
    const jun =
      tenant.status === 'paid' ? tenant.rent :
        tenant.status === 'partial' ? tenant.rent + tenant.balance :
          0;
    return { month, amount: i === 5 ? jun : i === 4 ? paid : 0 };
  });

  const infoItems = [
    { label: 'Move-in Date', value: tenant.moveInDate, Icon: Calendar },
    { label: 'Deposit Held', value: fmt(tenant.deposit), Icon: DollarSign },
    { label: 'Advance Months', value: `${tenant.advanceMonths} months`, Icon: Home },
    { label: 'Next Due Date', value: tenant.nextDueDate, Icon: Clock },
    { label: 'Phone', value: tenant.phone, Icon: Phone },
    { label: 'Monthly Rent', value: fmt(tenant.rent), Icon: DollarSign },
  ];

  return (
    <Dialog.Root open onOpenChange={open => !open && onClose()}>
      <Dialog.Portal>
        <Dialog.Overlay
          className="fixed inset-0 z-50"
          style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
        />
        <Dialog.Content
          className="fixed top-1/2 left-1/2 w-full max-w-2xl bg-background rounded-2xl z-50 overflow-hidden"
          style={{
            transform: 'translate(-50%, -50%)',
            maxHeight: '90vh',
            boxShadow: '0 25px 60px rgba(0,0,0,0.25)',
          }}
        >
          {/* Header */}
          <div className="flex items-center justify-between px-6 py-4" style={{ backgroundColor: '#1A5C3A' }}>
            <div className="flex items-center gap-3">
              <div
                className="w-11 h-11 rounded-full flex items-center justify-center"
                style={{ backgroundColor: 'rgba(255,255,255,0.18)' }}
              >
                <span className="text-white" style={{ fontWeight: 700, fontSize: '18px' }}>{tenant.name.charAt(0)}</span>
              </div>
              <div>
                <Dialog.Title className="text-white" style={{ fontWeight: 600, fontSize: '16px' }}>{tenant.name}</Dialog.Title>
                <p style={{ color: 'rgba(255,255,255,0.65)', fontSize: '13px' }}>Unit {tenant.unit}</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span
                className="px-2.5 py-1 rounded-full text-xs"
                style={{ backgroundColor: s.bg, color: s.text, fontWeight: 500 }}
              >
                {s.label}
              </span>
              <Dialog.Close asChild>
                <button
                  className="w-8 h-8 rounded-full flex items-center justify-center transition-colors"
                  style={{ backgroundColor: 'rgba(255,255,255,0.12)' }}
                  onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.22)')}
                  onMouseOut={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.12)')}
                >
                  <X className="w-4 h-4 text-white" />
                </button>
              </Dialog.Close>
            </div>
          </div>

          <div className="overflow-y-auto" style={{ maxHeight: 'calc(90vh - 80px)' }}>
            {/* Info grid */}
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 p-5" style={{ borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
              {infoItems.map(({ label, value, Icon }) => (
                <div key={label} className="rounded-xl p-3.5" style={{ backgroundColor: '#F5F3EF' }}>
                  <div className="flex items-center gap-1.5 mb-1">
                    <Icon className="w-3.5 h-3.5" style={{ color: '#6B7A6E' }} />
                    <span className="text-xs" style={{ color: '#6B7A6E' }}>{label}</span>
                  </div>
                  <p className="text-sm" style={{ color: '#1A2E1F', fontWeight: 600 }}>{value}</p>
                </div>
              ))}
            </div>

            {/* Balance indicator */}
            <div className="px-5 py-4" style={{ borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
              <div className="flex items-center justify-between">
                <span className="text-sm" style={{ color: '#6B7A6E' }}>Current Balance</span>
                <span
                  className="text-sm"
                  style={{ color: tenant.balance === 0 ? '#16a34a' : '#dc2626', fontWeight: 600 }}
                >
                  {tenant.balance === 0 ? 'Cleared' : `Owes ${fmt(Math.abs(tenant.balance))}`}
                </span>
              </div>
              {tenant.balance < 0 && (
                <div className="mt-2 h-1.5 rounded-full overflow-hidden" style={{ backgroundColor: '#fee2e2' }}>
                  <div
                    className="h-full rounded-full"
                    style={{
                      backgroundColor: '#dc2626',
                      width: `${Math.min(100, (Math.abs(tenant.balance) / tenant.rent) * 100)}%`,
                    }}
                  />
                </div>
              )}
            </div>

            {/* Payment chart */}
            <div className="px-5 py-5" style={{ borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
              <h3 className="mb-4" style={{ color: '#1A2E1F', fontWeight: 600, fontSize: '15px' }}>
                Payment Trend (Jan – Jun 2024)
              </h3>
              <div style={{ height: '140px' }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} barSize={24}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.05)" vertical={false} />
                    <XAxis
                      dataKey="month"
                      tick={{ fontSize: 11, fill: '#6B7A6E' }}
                      axisLine={false}
                      tickLine={false}
                    />
                    <YAxis hide />
                    <Tooltip
                      formatter={(val: number) => [fmt(val), 'Paid']}
                      contentStyle={{ borderRadius: '8px', border: '1px solid rgba(0,0,0,0.1)', fontSize: '12px' }}
                    />
                    <Bar dataKey="amount" radius={[4, 4, 0, 0]}>
                      {chartData.map((entry, i) => (
                        <Cell key={i} fill={entry.amount > 0 ? '#1A5C3A' : '#EEF1EE'} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Payment history */}
            <div className="p-5">
              <h3 className="mb-4" style={{ color: '#1A2E1F', fontWeight: 600, fontSize: '15px' }}>
                Payment History
              </h3>
              {tenantPayments.length > 0 ? (
                <table className="w-full">
                  <thead>
                    <tr style={{ borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
                      {['Date', 'Month Paid', 'Method', 'Reference', 'Amount'].map(h => (
                        <th key={h} className="pb-2.5 text-left text-xs" style={{ color: '#6B7A6E', fontWeight: 500 }}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {tenantPayments.map((payment, idx) => (
                      <tr
                        key={payment.id}
                        style={{ borderTop: idx > 0 ? '1px solid rgba(0,0,0,0.05)' : 'none' }}
                      >
                        <td className="py-3 text-sm" style={{ color: '#6B7A6E' }}>{payment.date}</td>
                        <td className="py-3 text-sm" style={{ color: '#1A2E1F' }}>{payment.monthPaid}</td>
                        <td className="py-3">
                          <span
                            className="inline-flex px-2 py-0.5 rounded-full text-xs"
                            style={{
                              backgroundColor:
                                payment.method === 'M-Pesa' ? '#dcfce7' :
                                  payment.method === 'Bank Transfer' ? '#dbeafe' : '#f3f4f6',
                              color:
                                payment.method === 'M-Pesa' ? '#15803d' :
                                  payment.method === 'Bank Transfer' ? '#1d4ed8' : '#374151',
                              fontWeight: 500,
                            }}
                          >
                            {payment.method}
                          </span>
                        </td>
                        <td className="py-3 text-xs font-mono" style={{ color: '#6B7A6E' }}>{payment.reference}</td>
                        <td className="py-3 text-sm text-right" style={{ color: '#16a34a', fontWeight: 600 }}>
                          +{fmt(payment.amount)}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="text-center py-8">
                  <p className="text-sm" style={{ color: '#6B7A6E' }}>No payment records found for this tenant.</p>
                </div>
              )}
            </div>
          </div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}
