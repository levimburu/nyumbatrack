import { useState } from 'react';
import * as DropdownMenu from '@radix-ui/react-dropdown-menu';
import {
  Building2, LayoutDashboard, Users, CreditCard, BarChart3,
  ChevronDown, Menu, X, LogOut,
} from 'lucide-react';
import { properties } from '../data';

export type Page = 'properties' | 'dashboard' | 'tenants' | 'payments' | 'reports';

interface AppLayoutProps {
  currentPage: Page;
  onNavigate: (page: Page) => void;
  selectedPropertyId: string;
  onSelectProperty: (id: string) => void;
  userName: string;
  role: 'landlord' | 'agent';
  onSignOut: () => void;
  children: React.ReactNode;
}

const NAV_ITEMS: { id: Page; label: string; Icon: React.ElementType }[] = [
  { id: 'properties', label: 'Properties', Icon: Building2 },
  { id: 'dashboard', label: 'Dashboard', Icon: LayoutDashboard },
  { id: 'tenants', label: 'Tenants', Icon: Users },
  { id: 'payments', label: 'Payments', Icon: CreditCard },
  { id: 'reports', label: 'Reports', Icon: BarChart3 },
];

export function AppLayout({
  currentPage, onNavigate, selectedPropertyId, onSelectProperty, userName, role, onSignOut, children,
}: AppLayoutProps) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const selectedProperty = properties.find(p => p.id === selectedPropertyId);
  const firstLetter = userName.charAt(0).toUpperCase();

  const SidebarContent = () => (
    <div className="h-full flex flex-col overflow-hidden" style={{ backgroundColor: '#0D3B2A' }}>
      {/* Logo */}
      <div className="px-5 pt-6 pb-5" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl flex items-center justify-center shadow-md" style={{ backgroundColor: '#D4900A' }}>
            <Building2 className="w-5 h-5 text-white" />
          </div>
          <span className="text-white tracking-tight" style={{ fontWeight: 700, fontSize: '18px' }}>NyumbaTrack</span>
        </div>
      </div>

      {/* Property selector */}
      {currentPage !== 'properties' && (
        <div className="px-4 py-4" style={{ borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
          <p className="text-xs mb-2 uppercase tracking-wider" style={{ color: 'rgba(255,255,255,0.35)', fontSize: '10px' }}>Current Property</p>
          <DropdownMenu.Root>
            <DropdownMenu.Trigger asChild>
              <button
                className="w-full flex items-center gap-2 px-3 py-2.5 rounded-xl transition-colors outline-none"
                style={{ backgroundColor: 'rgba(255,255,255,0.08)' }}
                onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.13)')}
                onMouseOut={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.08)')}
              >
                <Building2 className="w-4 h-4 flex-shrink-0" style={{ color: '#D4900A' }} />
                <span className="text-white text-sm truncate flex-1 text-left" style={{ fontWeight: 500 }}>
                  {selectedProperty?.name ?? 'Select Property'}
                </span>
                <ChevronDown className="w-4 h-4 flex-shrink-0" style={{ color: 'rgba(255,255,255,0.45)' }} />
              </button>
            </DropdownMenu.Trigger>
            <DropdownMenu.Portal>
              <DropdownMenu.Content
                className="w-56 rounded-xl p-1 z-50 shadow-xl"
                style={{ backgroundColor: '#0D3B2A', border: '1px solid rgba(255,255,255,0.12)' }}
                sideOffset={4}
              >
                {properties.map(p => (
                  <DropdownMenu.Item
                    key={p.id}
                    onSelect={() => onSelectProperty(p.id)}
                    className="flex items-center gap-2 px-3 py-2.5 rounded-lg cursor-pointer outline-none transition-colors text-sm"
                    style={{ color: p.id === selectedPropertyId ? '#D4900A' : 'rgba(255,255,255,0.75)' }}
                    onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)')}
                    onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                  >
                    <Building2 className="w-4 h-4 flex-shrink-0" />
                    <div className="min-w-0">
                      <div className="font-medium truncate">{p.name}</div>
                      <div className="text-xs truncate" style={{ color: 'rgba(255,255,255,0.4)' }}>{p.location}</div>
                    </div>
                  </DropdownMenu.Item>
                ))}
              </DropdownMenu.Content>
            </DropdownMenu.Portal>
          </DropdownMenu.Root>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-0.5 overflow-y-auto">
        {NAV_ITEMS.map(({ id, label, Icon }) => {
          const isActive = currentPage === id;
          return (
            <button
              key={id}
              onClick={() => { onNavigate(id); setSidebarOpen(false); }}
              className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm transition-all"
              style={{
                backgroundColor: isActive ? '#1A5C3A' : 'transparent',
                color: isActive ? '#ffffff' : 'rgba(255,255,255,0.6)',
                fontWeight: isActive ? 600 : 400,
              }}
              onMouseOver={e => { if (!isActive) e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.07)'; }}
              onMouseOut={e => { if (!isActive) e.currentTarget.style.backgroundColor = 'transparent'; }}
            >
              <Icon className="w-5 h-5 flex-shrink-0" style={{ color: isActive ? '#D4900A' : 'rgba(255,255,255,0.5)' }} />
              <span className="flex-1 text-left">{label}</span>
              {isActive && <div className="w-1.5 h-1.5 rounded-full flex-shrink-0" style={{ backgroundColor: '#D4900A' }} />}
            </button>
          );
        })}
      </nav>

      {/* User section */}
      <div className="px-4 pb-5 pt-4" style={{ borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <div className="flex items-center gap-3 px-3 py-3 rounded-xl" style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}>
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center flex-shrink-0"
            style={{ backgroundColor: '#D4900A' }}
          >
            <span className="text-white text-sm" style={{ fontWeight: 700 }}>{firstLetter}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm truncate" style={{ fontWeight: 500 }}>{userName}</p>
            <p className="text-xs capitalize" style={{ color: 'rgba(255,255,255,0.45)' }}>{role}</p>
          </div>
          <button
            onClick={onSignOut}
            className="w-7 h-7 rounded-lg flex items-center justify-center transition-colors flex-shrink-0"
            title="Sign out"
            style={{ color: 'rgba(255,255,255,0.35)' }}
            onMouseOver={e => { e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)'; e.currentTarget.style.color = 'rgba(255,255,255,0.75)'; }}
            onMouseOut={e => { e.currentTarget.style.backgroundColor = 'transparent'; e.currentTarget.style.color = 'rgba(255,255,255,0.35)'; }}
          >
            <LogOut className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="h-screen w-full flex bg-background overflow-hidden">
      {/* Desktop sidebar */}
      <div className="hidden md:flex w-60 flex-shrink-0 flex-col">
        <SidebarContent />
      </div>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div
            className="absolute inset-0"
            style={{ backgroundColor: 'rgba(0,0,0,0.55)' }}
            onClick={() => setSidebarOpen(false)}
          />
          <div className="absolute left-0 top-0 h-full w-64">
            <SidebarContent />
          </div>
          <button
            onClick={() => setSidebarOpen(false)}
            className="absolute top-4 right-4 w-9 h-9 rounded-full flex items-center justify-center"
            style={{ backgroundColor: 'rgba(255,255,255,0.15)' }}
          >
            <X className="w-5 h-5 text-white" />
          </button>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden min-w-0">
        {/* Mobile header */}
        <div
          className="md:hidden flex items-center justify-between px-4 py-3 flex-shrink-0"
          style={{ backgroundColor: '#ffffff', borderBottom: '1px solid rgba(0,0,0,0.08)' }}
        >
          <button
            onClick={() => setSidebarOpen(true)}
            className="w-9 h-9 rounded-lg flex items-center justify-center"
            style={{ backgroundColor: '#EEF1EE' }}
          >
            <Menu className="w-5 h-5" style={{ color: '#1A2E1F' }} />
          </button>
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ backgroundColor: '#D4900A' }}>
              <Building2 className="w-4 h-4 text-white" />
            </div>
            <span style={{ fontWeight: 700, color: '#1A2E1F' }}>NyumbaTrack</span>
          </div>
          <div
            className="w-9 h-9 rounded-full flex items-center justify-center"
            style={{ backgroundColor: '#D4900A' }}
          >
            <span className="text-white text-sm" style={{ fontWeight: 700 }}>{firstLetter}</span>
          </div>
        </div>

        {/* Page content */}
        <div className="flex-1 overflow-auto">
          {children}
        </div>
      </div>
    </div>
  );
}
