import { useState } from 'react';
import { Plus, Eye, Edit2, Search } from 'lucide-react';
import { properties, tenants, fmt } from '../data';
import { TenantProfileModal } from './TenantProfileModal';

interface TenantsScreenProps {
  propertyId: string;
}

const STATUS_CONFIG = {
  paid: { label: 'Paid', bg: '#dcfce7', text: '#15803d' },
  partial: { label: 'Partial', bg: '#fef3c7', text: '#b45309' },
  unpaid: { label: 'Unpaid', bg: '#fee2e2', text: '#b91c1c' },
};

export function TenantsScreen({ propertyId }: TenantsScreenProps) {
  const [selectedTenantId, setSelectedTenantId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');

  const property = properties.find(p => p.id === propertyId)!;
  const propTenants = tenants.filter(t => t.propertyId === propertyId).filter(t =>
    searchQuery === '' ||
    t.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.unit.toLowerCase().includes(searchQuery.toLowerCase())
  );
  const selectedTenant = tenants.find(t => t.id === selectedTenantId);

  return (
    <div className="p-4 md:p-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-5">
        <div>
          <h1 className="text-foreground">Tenants</h1>
          <p className="text-sm" style={{ color: '#6B7A6E' }}>
            {property.name} · {propTenants.length} tenant{propTenants.length !== 1 ? 's' : ''}
          </p>
        </div>
        <button
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm text-white transition-colors"
          style={{ backgroundColor: '#1A5C3A', fontWeight: 500 }}
          onMouseOver={e => (e.currentTarget.style.backgroundColor = '#155030')}
          onMouseOut={e => (e.currentTarget.style.backgroundColor = '#1A5C3A')}
        >
          <Plus className="w-4 h-4" />
          <span className="hidden sm:inline">Add Tenant</span>
        </button>
      </div>

      {/* Search */}
      <div className="relative mb-4">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4" style={{ color: '#6B7A6E' }} />
        <input
          type="text"
          placeholder="Search by name or unit..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          className="w-full pl-10 pr-4 py-2.5 rounded-xl text-sm outline-none bg-card"
          style={{
            border: '1px solid rgba(0,0,0,0.1)',
            color: '#1A2E1F',
          }}
          onFocus={e => {
            e.currentTarget.style.borderColor = '#1A5C3A';
            e.currentTarget.style.boxShadow = '0 0 0 3px rgba(26,92,58,0.1)';
          }}
          onBlur={e => {
            e.currentTarget.style.borderColor = 'rgba(0,0,0,0.1)';
            e.currentTarget.style.boxShadow = 'none';
          }}
        />
      </div>

      {/* Desktop table */}
      <div
        className="hidden md:block bg-card rounded-2xl overflow-hidden"
        style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 6px rgba(0,0,0,0.04)' }}
      >
        <table className="w-full">
          <thead>
            <tr style={{ backgroundColor: 'rgba(0,0,0,0.025)' }}>
              {['Name', 'Unit', 'Phone', 'Rent', 'Balance', 'Next Due', 'Status', 'Actions'].map(h => (
                <th key={h} className="px-4 py-3 text-left text-xs" style={{ color: '#6B7A6E', fontWeight: 500, borderBottom: '1px solid rgba(0,0,0,0.07)' }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {propTenants.map((tenant, idx) => {
              const s = STATUS_CONFIG[tenant.status];
              const balanceText = tenant.balance === 0 ? 'Clear' : `(${fmt(Math.abs(tenant.balance))})`;
              const balanceColor = tenant.balance === 0 ? '#16a34a' : '#dc2626';
              return (
                <tr
                  key={tenant.id}
                  style={{ borderTop: idx > 0 ? '1px solid rgba(0,0,0,0.05)' : 'none', cursor: 'default' }}
                  onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(0,0,0,0.02)')}
                  onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                >
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0"
                        style={{ backgroundColor: 'rgba(26,92,58,0.1)' }}
                      >
                        <span className="text-xs" style={{ color: '#1A5C3A', fontWeight: 600 }}>{tenant.name.charAt(0)}</span>
                      </div>
                      <span className="text-sm" style={{ color: '#1A2E1F', fontWeight: 500 }}>{tenant.name}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5 text-sm font-mono" style={{ color: '#6B7A6E' }}>{tenant.unit}</td>
                  <td className="px-4 py-3.5 text-sm" style={{ color: '#6B7A6E' }}>{tenant.phone}</td>
                  <td className="px-4 py-3.5 text-sm" style={{ color: '#1A2E1F', fontWeight: 500 }}>{fmt(tenant.rent)}</td>
                  <td className="px-4 py-3.5 text-sm" style={{ color: balanceColor, fontWeight: 500 }}>{balanceText}</td>
                  <td className="px-4 py-3.5 text-sm" style={{ color: '#6B7A6E' }}>{tenant.nextDueDate}</td>
                  <td className="px-4 py-3.5">
                    <span
                      className="inline-flex px-2.5 py-1 rounded-full text-xs"
                      style={{ backgroundColor: s.bg, color: s.text, fontWeight: 500 }}
                    >
                      {s.label}
                    </span>
                  </td>
                  <td className="px-4 py-3.5">
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => setSelectedTenantId(tenant.id)}
                        className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
                        title="View profile"
                        onMouseOver={e => (e.currentTarget.style.backgroundColor = '#EEF1EE')}
                        onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                      >
                        <Eye className="w-4 h-4" style={{ color: '#6B7A6E' }} />
                      </button>
                      <button
                        className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors"
                        title="Edit tenant"
                        onMouseOver={e => (e.currentTarget.style.backgroundColor = '#EEF1EE')}
                        onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                      >
                        <Edit2 className="w-4 h-4" style={{ color: '#6B7A6E' }} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Mobile cards */}
      <div className="md:hidden space-y-3">
        {propTenants.map(tenant => {
          const s = STATUS_CONFIG[tenant.status];
          return (
            <button
              key={tenant.id}
              onClick={() => setSelectedTenantId(tenant.id)}
              className="w-full bg-card rounded-2xl p-4 text-left transition-all"
              style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 4px rgba(0,0,0,0.05)' }}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center"
                    style={{ backgroundColor: 'rgba(26,92,58,0.1)' }}
                  >
                    <span style={{ color: '#1A5C3A', fontWeight: 600 }}>{tenant.name.charAt(0)}</span>
                  </div>
                  <div>
                    <p className="text-sm" style={{ color: '#1A2E1F', fontWeight: 600 }}>{tenant.name}</p>
                    <p className="text-xs" style={{ color: '#6B7A6E' }}>Unit {tenant.unit}</p>
                  </div>
                </div>
                <span
                  className="px-2.5 py-1 rounded-full text-xs"
                  style={{ backgroundColor: s.bg, color: s.text, fontWeight: 500 }}
                >
                  {s.label}
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <p className="text-xs" style={{ color: '#6B7A6E' }}>Rent</p>
                  <p className="text-sm" style={{ color: '#1A2E1F', fontWeight: 600 }}>{fmt(tenant.rent)}</p>
                </div>
                <div>
                  <p className="text-xs" style={{ color: '#6B7A6E' }}>Next Due</p>
                  <p className="text-sm" style={{ color: '#1A2E1F', fontWeight: 600 }}>{tenant.nextDueDate}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {selectedTenant && (
        <TenantProfileModal tenant={selectedTenant} onClose={() => setSelectedTenantId(null)} />
      )}
    </div>
  );
}
