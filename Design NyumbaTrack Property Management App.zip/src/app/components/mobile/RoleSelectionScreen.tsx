import { useState } from 'react';
import { ArrowLeft, Building2, UserCheck, CheckCircle2 } from 'lucide-react';

interface RoleSelectionScreenProps {
  onBack: () => void;
  onSelectRole: (role: 'landlord' | 'agent') => void;
}

export function RoleSelectionScreen({ onBack, onSelectRole }: RoleSelectionScreenProps) {
  const [selected, setSelected] = useState<'landlord' | 'agent' | null>(null);

  return (
    <div className="w-full h-full flex flex-col" style={{ backgroundColor: '#F5F3EF' }}>
      {/* Header */}
      <div className="pt-14 pb-8 px-6" style={{ backgroundColor: '#0D3B2A' }}>
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center mb-6 transition-colors"
          style={{ backgroundColor: 'rgba(255,255,255,0.12)' }}
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
        <h1 className="text-white mb-1" style={{ fontWeight: 700, fontSize: '22px' }}>Who are you?</h1>
        <p className="text-sm" style={{ color: 'rgba(255,255,255,0.55)' }}>Select your role to get started</p>
      </div>

      {/* Cards */}
      <div className="flex-1 px-5 pt-6 flex flex-col gap-4">
        {/* Landlord */}
        <button
          onClick={() => setSelected('landlord')}
          className="w-full p-5 rounded-2xl text-left transition-all"
          style={{
            backgroundColor: '#ffffff',
            border: selected === 'landlord' ? '2px solid #1A5C3A' : '2px solid transparent',
            boxShadow: selected === 'landlord' ? '0 4px 20px rgba(26,92,58,0.15)' : '0 1px 6px rgba(0,0,0,0.06)',
          }}
        >
          <div className="flex items-start justify-between">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4"
              style={{ backgroundColor: selected === 'landlord' ? '#1A5C3A' : '#EEF5F0' }}
            >
              <Building2
                className="w-8 h-8"
                style={{ color: selected === 'landlord' ? '#ffffff' : '#1A5C3A' }}
              />
            </div>
            {selected === 'landlord' && (
              <CheckCircle2 className="w-5 h-5 mt-1" style={{ color: '#1A5C3A' }} />
            )}
          </div>
          <h3 className="mb-1" style={{ color: '#1A2E1F', fontWeight: 600, fontSize: '17px' }}>Landlord</h3>
          <p className="text-sm" style={{ color: '#6B7A6E' }}>
            I own properties and want to track my rental income
          </p>
        </button>

        {/* Agent */}
        <button
          onClick={() => setSelected('agent')}
          className="w-full p-5 rounded-2xl text-left transition-all"
          style={{
            backgroundColor: '#ffffff',
            border: selected === 'agent' ? '2px solid #1A5C3A' : '2px solid transparent',
            boxShadow: selected === 'agent' ? '0 4px 20px rgba(26,92,58,0.15)' : '0 1px 6px rgba(0,0,0,0.06)',
          }}
        >
          <div className="flex items-start justify-between">
            <div
              className="w-14 h-14 rounded-2xl flex items-center justify-center mb-4"
              style={{ backgroundColor: selected === 'agent' ? '#1A5C3A' : '#EEF5F0' }}
            >
              <UserCheck
                className="w-8 h-8"
                style={{ color: selected === 'agent' ? '#ffffff' : '#1A5C3A' }}
              />
            </div>
            {selected === 'agent' && (
              <CheckCircle2 className="w-5 h-5 mt-1" style={{ color: '#1A5C3A' }} />
            )}
          </div>
          <h3 className="mb-1" style={{ color: '#1A2E1F', fontWeight: 600, fontSize: '17px' }}>Property Agent</h3>
          <p className="text-sm" style={{ color: '#6B7A6E' }}>
            I manage properties on behalf of landlords
          </p>
        </button>
      </div>

      {/* Continue button */}
      <div className="px-5 pb-10">
        <button
          onClick={() => selected && onSelectRole(selected)}
          disabled={!selected}
          className="w-full py-4 rounded-2xl text-base transition-all active:scale-95"
          style={{
            backgroundColor: selected ? '#1A5C3A' : '#C5C8C5',
            color: selected ? '#ffffff' : '#8A8E8A',
            fontWeight: 600,
            cursor: selected ? 'pointer' : 'not-allowed',
          }}
        >
          Continue
        </button>
      </div>
    </div>
  );
}
