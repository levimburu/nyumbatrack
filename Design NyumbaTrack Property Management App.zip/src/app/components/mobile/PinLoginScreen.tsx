import { useState } from 'react';
import { Delete, LogOut } from 'lucide-react';

interface PinLoginScreenProps {
  userName: string;
  correctPin: string;
  onSuccess: () => void;
  onBack: () => void;
}

const KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'];

export function PinLoginScreen({ userName, correctPin, onSuccess, onBack }: PinLoginScreenProps) {
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');
  const [shake, setShake] = useState(false);

  const firstName = userName ? userName.split(' ')[0] : 'Guest';
  const firstLetter = firstName.charAt(0).toUpperCase();

  const handleKey = (key: string) => {
    if (pin.length >= 4) return;
    const newPin = pin + key;
    setPin(newPin);
    setError('');

    if (newPin.length === 4) {
      setTimeout(() => {
        const isCorrect = correctPin === '' || newPin === correctPin;
        if (isCorrect) {
          onSuccess();
        } else {
          setShake(true);
          setError('Incorrect PIN. Try again.');
          setPin('');
          setTimeout(() => setShake(false), 600);
        }
      }, 200);
    }
  };

  const handleDelete = () => {
    setPin(p => p.slice(0, -1));
    setError('');
  };

  return (
    <div className="w-full h-full flex flex-col" style={{ backgroundColor: '#0D3B2A' }}>
      {/* Top bar */}
      <div className="pt-14 px-6 flex justify-end">
        <button
          onClick={onBack}
          className="flex items-center gap-1.5 transition-colors"
          style={{ color: 'rgba(255,255,255,0.45)', fontSize: '13px' }}
          onMouseOver={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.75)')}
          onMouseOut={e => (e.currentTarget.style.color = 'rgba(255,255,255,0.45)')}
        >
          <LogOut className="w-4 h-4" />
          Switch Account
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center px-6 pt-8">
        {/* Avatar */}
        <div
          className="w-20 h-20 rounded-full flex items-center justify-center mb-4 shadow-xl"
          style={{ backgroundColor: '#D4900A' }}
        >
          <span className="text-white" style={{ fontSize: '30px', fontWeight: 700 }}>{firstLetter}</span>
        </div>

        <p className="text-white mb-1" style={{ fontSize: '15px', color: 'rgba(255,255,255,0.65)' }}>Welcome back</p>
        <h2 className="text-white mb-10" style={{ fontSize: '24px', fontWeight: 700 }}>{firstName}</h2>

        {/* PIN dots */}
        <div
          className="flex gap-5 mb-3"
          style={{
            animation: shake ? 'shake 0.5s ease' : 'none',
          }}
        >
          {[0, 1, 2, 3].map(i => (
            <div
              key={i}
              className="w-4 h-4 rounded-full transition-all duration-200"
              style={{
                backgroundColor: i < pin.length ? '#D4900A' : error ? 'rgba(248,113,113,0.6)' : 'rgba(255,255,255,0.2)',
                transform: i < pin.length ? 'scale(1.15)' : 'scale(1)',
              }}
            />
          ))}
        </div>

        {error ? (
          <p className="text-red-400 text-sm mb-4">{error}</p>
        ) : (
          <p className="text-sm mb-4" style={{ color: 'rgba(255,255,255,0.4)' }}>Enter your PIN</p>
        )}

        {/* Keypad */}
        <div className="grid grid-cols-3 gap-3 w-full max-w-[300px] mt-3">
          {KEYS.map((key, i) => {
            if (key === '') return <div key={i} />;
            if (key === 'del') {
              return (
                <button
                  key={i}
                  onClick={handleDelete}
                  className="h-16 w-full rounded-2xl flex items-center justify-center transition-all active:scale-95"
                  style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
                  onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.18)')}
                  onMouseOut={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)')}
                >
                  <Delete className="w-6 h-6 text-white" />
                </button>
              );
            }
            return (
              <button
                key={i}
                onClick={() => handleKey(key)}
                className="h-16 w-full rounded-2xl text-white transition-all active:scale-95"
                style={{ backgroundColor: 'rgba(255,255,255,0.1)', fontSize: '24px', fontWeight: 300 }}
                onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.18)')}
                onMouseOut={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)')}
              >
                {key}
              </button>
            );
          })}
        </div>

        <p className="text-xs mt-8" style={{ color: 'rgba(255,255,255,0.25)' }}>
          {correctPin ? 'Use the PIN you just created' : 'Enter any 4 digits to continue'}
        </p>
      </div>

      <style>{`
        @keyframes shake {
          0%, 100% { transform: translateX(0); }
          20% { transform: translateX(-8px); }
          40% { transform: translateX(8px); }
          60% { transform: translateX(-6px); }
          80% { transform: translateX(6px); }
        }
      `}</style>
    </div>
  );
}
