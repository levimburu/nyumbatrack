import { useState } from 'react';
import { ArrowLeft, Delete } from 'lucide-react';

interface PinSetupScreenProps {
  onBack: () => void;
  onComplete: (pin: string) => void;
}

const KEYS = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '', '0', 'del'];

export function PinSetupScreen({ onBack, onComplete }: PinSetupScreenProps) {
  const [stage, setStage] = useState<'enter' | 'confirm' | 'success'>('enter');
  const [firstPin, setFirstPin] = useState('');
  const [currentPin, setCurrentPin] = useState('');
  const [error, setError] = useState('');

  const handleKey = (key: string) => {
    if (currentPin.length >= 4) return;
    const newPin = currentPin + key;
    setCurrentPin(newPin);
    setError('');

    if (newPin.length === 4) {
      setTimeout(() => {
        if (stage === 'enter') {
          setFirstPin(newPin);
          setCurrentPin('');
          setStage('confirm');
        } else {
          if (newPin === firstPin) {
            setStage('success');
            setTimeout(() => onComplete(newPin), 1400);
          } else {
            setError("PINs don't match. Try again.");
            setCurrentPin('');
          }
        }
      }, 200);
    }
  };

  const handleDelete = () => {
    setCurrentPin(p => p.slice(0, -1));
    setError('');
  };

  return (
    <div className="w-full h-full flex flex-col" style={{ backgroundColor: '#0D3B2A' }}>
      {/* Header */}
      <div className="pt-14 px-6 pb-4">
        <button
          onClick={onBack}
          className="w-10 h-10 rounded-full flex items-center justify-center"
          style={{ backgroundColor: 'rgba(255,255,255,0.12)' }}
        >
          <ArrowLeft className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Content */}
      <div className="flex-1 flex flex-col items-center px-6 pt-6">
        {stage === 'success' ? (
          <div className="flex flex-col items-center justify-center flex-1">
            <div
              className="w-20 h-20 rounded-full flex items-center justify-center mb-5 shadow-lg"
              style={{ backgroundColor: '#D4900A' }}
            >
              <svg width="36" height="28" viewBox="0 0 36 28" fill="none">
                <path d="M3 14L13 24L33 3" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <h2 className="text-white mb-2" style={{ fontSize: '22px', fontWeight: 700 }}>PIN Created!</h2>
            <p style={{ color: 'rgba(255,255,255,0.55)', fontSize: '14px', textAlign: 'center' }}>
              Your account is now secured
            </p>
          </div>
        ) : (
          <>
            <div className="mb-2 text-center">
              <div
                className="w-14 h-14 rounded-2xl flex items-center justify-center mx-auto mb-5"
                style={{ backgroundColor: 'rgba(212,144,10,0.2)' }}
              >
                <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                  <rect x="3" y="11" width="18" height="11" rx="2" stroke="#D4900A" strokeWidth="2" />
                  <path d="M7 11V7a5 5 0 0 1 10 0v4" stroke="#D4900A" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </div>
              <h2 className="text-white mb-1.5" style={{ fontSize: '22px', fontWeight: 700 }}>
                {stage === 'enter' ? 'Create your PIN' : 'Confirm your PIN'}
              </h2>
              <p style={{ color: 'rgba(255,255,255,0.5)', fontSize: '14px' }}>
                {stage === 'enter' ? 'Enter a 4-digit PIN to secure your account' : 'Re-enter your PIN to confirm'}
              </p>
            </div>

            {/* PIN dots */}
            <div className="flex gap-5 my-8">
              {[0, 1, 2, 3].map(i => (
                <div
                  key={i}
                  className="w-4 h-4 rounded-full transition-all duration-200"
                  style={{
                    backgroundColor: i < currentPin.length ? '#D4900A' : 'rgba(255,255,255,0.2)',
                    transform: i < currentPin.length ? 'scale(1.15)' : 'scale(1)',
                  }}
                />
              ))}
            </div>

            {error && (
              <p className="text-red-400 text-sm mb-4 text-center">{error}</p>
            )}

            {/* Keypad */}
            <div className="grid grid-cols-3 gap-3 w-full max-w-[300px] mt-2">
              {KEYS.map((key, i) => {
                if (key === '') return <div key={i} />;
                if (key === 'del') {
                  return (
                    <button
                      key={i}
                      onClick={handleDelete}
                      className="h-16 w-full rounded-2xl flex items-center justify-center transition-all active:scale-95"
                      style={{ backgroundColor: 'rgba(255,255,255,0.1)' }}
                      onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.18)')}
                      onMouseOut={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)')}
                    >
                      <Delete className="w-6 h-6 text-white" />
                    </button>
                  );
                }
                return (
                  <button
                    key={i}
                    onClick={() => handleKey(key)}
                    className="h-16 w-full rounded-2xl text-white transition-all active:scale-95"
                    style={{ backgroundColor: 'rgba(255,255,255,0.1)', fontSize: '24px', fontWeight: 300 }}
                    onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.18)')}
                    onMouseOut={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.1)')}
                  >
                    {key}
                  </button>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
