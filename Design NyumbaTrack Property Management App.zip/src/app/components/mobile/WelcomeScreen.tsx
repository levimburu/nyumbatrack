import { Building2 } from 'lucide-react';

interface WelcomeScreenProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

export function WelcomeScreen({ onGetStarted, onSignIn }: WelcomeScreenProps) {
  return (
    <div className="w-full h-full flex flex-col relative overflow-hidden" style={{ backgroundColor: '#0D3B2A' }}>
      {/* Decorative circles */}
      <div className="absolute top-[-80px] right-[-60px] w-64 h-64 rounded-full" style={{ backgroundColor: 'rgba(255,255,255,0.04)' }} />
      <div className="absolute bottom-[-60px] left-[-50px] w-56 h-56 rounded-full" style={{ backgroundColor: 'rgba(255,255,255,0.04)' }} />
      <div className="absolute top-[38%] left-[-100px] w-48 h-48 rounded-full" style={{ backgroundColor: 'rgba(26,92,58,0.4)' }} />

      {/* Content area */}
      <div className="flex-1 flex flex-col items-center justify-center px-8 pt-16 pb-6 relative z-10">
        {/* Logo */}
        <div className="flex items-center gap-3 mb-14">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg" style={{ backgroundColor: '#D4900A' }}>
            <Building2 className="w-7 h-7 text-white" />
          </div>
          <span className="text-white text-2xl tracking-tight" style={{ fontWeight: 700 }}>NyumbaTrack</span>
        </div>

        {/* City illustration */}
        <div className="mb-10">
          <svg width="260" height="190" viewBox="0 0 260 190" fill="none" xmlns="http://www.w3.org/2000/svg">
            <rect width="260" height="190" rx="20" fill="#0A3020" />
            {/* Moon */}
            <circle cx="210" cy="32" r="14" fill="#D4900A" opacity="0.9" />
            <circle cx="217" cy="27" r="10" fill="#0A3020" />
            {/* Stars */}
            <circle cx="30" cy="22" r="1.5" fill="white" opacity="0.7" />
            <circle cx="75" cy="16" r="1" fill="white" opacity="0.5" />
            <circle cx="155" cy="14" r="1.5" fill="white" opacity="0.6" />
            <circle cx="238" cy="18" r="1" fill="white" opacity="0.7" />
            <circle cx="50" cy="38" r="1" fill="white" opacity="0.4" />
            {/* Ground */}
            <rect x="0" y="162" width="260" height="28" fill="#0F4A2E" />
            {/* Left building */}
            <rect x="18" y="88" width="56" height="78" rx="3" fill="#155030" />
            <rect x="26" y="98" width="12" height="12" rx="2" fill="#D4900A" opacity="0.7" />
            <rect x="45" y="98" width="12" height="12" rx="2" fill="white" opacity="0.25" />
            <rect x="26" y="118" width="12" height="12" rx="2" fill="white" opacity="0.3" />
            <rect x="45" y="118" width="12" height="12" rx="2" fill="#D4900A" opacity="0.6" />
            <rect x="26" y="138" width="12" height="12" rx="2" fill="#D4900A" opacity="0.5" />
            <rect x="45" y="138" width="12" height="12" rx="2" fill="white" opacity="0.2" />
            {/* Center tall building */}
            <rect x="96" y="52" width="68" height="114" rx="4" fill="#1A5C3A" />
            <rect x="106" y="64" width="12" height="14" rx="2" fill="#D4900A" opacity="0.9" />
            <rect x="125" y="64" width="12" height="14" rx="2" fill="#D4900A" opacity="0.7" />
            <rect x="144" y="64" width="12" height="14" rx="2" fill="white" opacity="0.3" />
            <rect x="106" y="86" width="12" height="14" rx="2" fill="white" opacity="0.25" />
            <rect x="125" y="86" width="12" height="14" rx="2" fill="#D4900A" opacity="0.8" />
            <rect x="144" y="86" width="12" height="14" rx="2" fill="#D4900A" opacity="0.65" />
            <rect x="106" y="108" width="12" height="14" rx="2" fill="#D4900A" opacity="0.6" />
            <rect x="125" y="108" width="12" height="14" rx="2" fill="white" opacity="0.3" />
            <rect x="144" y="108" width="12" height="14" rx="2" fill="#D4900A" opacity="0.7" />
            {/* Door center */}
            <rect x="122" y="138" width="20" height="28" rx="2" fill="#0A3020" />
            {/* Right building */}
            <rect x="182" y="74" width="60" height="92" rx="3" fill="#1A5C3A" opacity="0.85" />
            <rect x="190" y="84" width="12" height="12" rx="2" fill="#D4900A" opacity="0.7" />
            <rect x="210" y="84" width="12" height="12" rx="2" fill="white" opacity="0.25" />
            <rect x="190" y="104" width="12" height="12" rx="2" fill="white" opacity="0.3" />
            <rect x="210" y="104" width="12" height="12" rx="2" fill="#D4900A" opacity="0.75" />
            <rect x="190" y="124" width="12" height="12" rx="2" fill="#D4900A" opacity="0.55" />
            <rect x="210" y="124" width="12" height="12" rx="2" fill="white" opacity="0.2" />
            {/* Trees */}
            <rect x="4" y="148" width="5" height="16" fill="#0A3020" />
            <circle cx="6.5" cy="144" r="10" fill="#144228" />
            <rect x="248" y="148" width="5" height="16" fill="#0A3020" />
            <circle cx="250.5" cy="144" r="10" fill="#144228" />
          </svg>
        </div>

        {/* Headline */}
        <h1 className="text-white text-center mb-3" style={{ fontSize: '26px', fontWeight: 700, lineHeight: 1.3 }}>
          Manage your properties<br />with ease
        </h1>
        <p className="text-center text-sm" style={{ color: 'rgba(255,255,255,0.55)' }}>
          Track rent, tenants &amp; payments — all in one place
        </p>
      </div>

      {/* Buttons */}
      <div className="px-8 pb-10 flex flex-col gap-3 relative z-10">
        <button
          onClick={onGetStarted}
          className="w-full py-4 rounded-2xl text-white text-base transition-all active:scale-95"
          style={{ backgroundColor: '#D4900A', fontWeight: 600 }}
          onMouseOver={e => (e.currentTarget.style.backgroundColor = '#C07B08')}
          onMouseOut={e => (e.currentTarget.style.backgroundColor = '#D4900A')}
        >
          Get Started
        </button>
        <button
          onClick={onSignIn}
          className="w-full py-4 rounded-2xl text-white text-base transition-all active:scale-95"
          style={{ border: '2px solid rgba(255,255,255,0.3)', fontWeight: 600 }}
          onMouseOver={e => (e.currentTarget.style.backgroundColor = 'rgba(255,255,255,0.08)')}
          onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
        >
          Sign In
        </button>
      </div>
    </div>
  );
}
