import { TrendingUp, CreditCard, BarChart3, Download } from 'lucide-react';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell,
} from 'recharts';
import { payments, monthlyIncome, properties, fmt } from '../data';

interface ReportsScreenProps {
  propertyId: string;
}

export function ReportsScreen({ propertyId }: ReportsScreenProps) {
  const property = properties.find(p => p.id === propertyId)!;
  const propPayments = payments.filter(p => p.propertyId === propertyId);
  const totalCollected = propPayments.reduce((sum, p) => sum + p.amount, 0);
  const monthlyAvg = propPayments.length > 0 ? Math.round(totalCollected / 6) : 0;

  const statCards = [
    { label: 'Total Collected (YTD)', value: fmt(totalCollected), Icon: TrendingUp, bg: '#F0FDF4', iconColor: '#16A34A' },
    { label: 'Monthly Average', value: fmt(monthlyAvg), Icon: CreditCard, bg: '#EFF6FF', iconColor: '#2563EB' },
    { label: 'Payments Recorded', value: String(propPayments.length), Icon: BarChart3, bg: '#FAF5FF', iconColor: '#7C3AED' },
  ];

  const methodTotals = ['M-Pesa', 'Bank Transfer', 'Cash'].map(method => {
    const methodPayments = propPayments.filter(p => p.method === method);
    const amount = methodPayments.reduce((sum, p) => sum + p.amount, 0);
    const pct = totalCollected > 0 ? Math.round((amount / totalCollected) * 100) : 0;
    return { method, amount, pct };
  });

  return (
    <div className="p-4 md:p-6 max-w-5xl mx-auto">
      {/* Header */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-foreground">Reports</h1>
          <p className="text-sm" style={{ color: '#6B7A6E' }}>{property.name} · Financial overview</p>
        </div>
        <button
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm transition-colors"
          style={{ border: '1px solid rgba(0,0,0,0.1)', color: '#1A2E1F', fontWeight: 500 }}
          onMouseOver={e => (e.currentTarget.style.backgroundColor = '#EEF1EE')}
          onMouseOut={e => (e.currentTarget.style.backgroundColor = 'transparent')}
        >
          <Download className="w-4 h-4" />
          Export PDF
        </button>
      </div>

      {/* Stat cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-5">
        {statCards.map(({ label, value, Icon, bg, iconColor }) => (
          <div
            key={label}
            className="bg-card rounded-2xl p-5"
            style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 6px rgba(0,0,0,0.04)' }}
          >
            <div className="w-10 h-10 rounded-xl flex items-center justify-center mb-3" style={{ backgroundColor: bg }}>
              <Icon className="w-5 h-5" style={{ color: iconColor }} />
            </div>
            <p className="text-xs mb-1" style={{ color: '#6B7A6E' }}>{label}</p>
            <p style={{ color: '#1A2E1F', fontWeight: 700, fontSize: '20px' }}>{value}</p>
          </div>
        ))}
      </div>

      {/* Monthly income bar chart */}
      <div
        className="bg-card rounded-2xl p-5 mb-4"
        style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 6px rgba(0,0,0,0.04)' }}
      >
        <div className="flex items-start justify-between mb-5">
          <div>
            <h3 style={{ color: '#1A2E1F', fontWeight: 600 }}>Monthly Rent Collected</h3>
            <p className="text-sm mt-0.5" style={{ color: '#6B7A6E' }}>Jan – Jun 2024</p>
          </div>
          <div className="flex items-center gap-3 text-xs" style={{ color: '#6B7A6E' }}>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: '#1A5C3A' }} />
              <span>Collected</span>
            </div>
            <div className="flex items-center gap-1.5">
              <div className="w-3 h-3 rounded-sm" style={{ backgroundColor: '#D4900A' }} />
              <span>Current month</span>
            </div>
          </div>
        </div>
        <div style={{ height: '240px' }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={monthlyIncome} barSize={36}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,0,0,0.05)" vertical={false} />
              <XAxis
                dataKey="month"
                tick={{ fontSize: 12, fill: '#6B7A6E' }}
                axisLine={false}
                tickLine={false}
              />
              <YAxis
                tickFormatter={v => `${v / 1000}K`}
                tick={{ fontSize: 11, fill: '#6B7A6E' }}
                axisLine={false}
                tickLine={false}
                width={40}
              />
              <Tooltip
                formatter={(val: number) => [fmt(val), 'Collected']}
                contentStyle={{
                  borderRadius: '10px',
                  border: '1px solid rgba(0,0,0,0.08)',
                  fontSize: '12px',
                  padding: '8px 12px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
                }}
              />
              <Bar dataKey="amount" radius={[6, 6, 0, 0]}>
                {monthlyIncome.map((_, i) => (
                  <Cell
                    key={i}
                    fill={i === monthlyIncome.length - 1 ? '#D4900A' : '#1A5C3A'}
                    opacity={i === monthlyIncome.length - 1 ? 1 : 0.87}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <p className="text-xs text-right mt-1" style={{ color: '#9CA3AF' }}>* June 2024 is a partial month</p>
      </div>

      {/* Payment methods breakdown */}
      <div
        className="bg-card rounded-2xl p-5"
        style={{ border: '1px solid rgba(0,0,0,0.07)', boxShadow: '0 1px 6px rgba(0,0,0,0.04)' }}
      >
        <h3 className="mb-5" style={{ color: '#1A2E1F', fontWeight: 600 }}>Payment Methods Breakdown</h3>
        <div className="space-y-5">
          {methodTotals.map(({ method, amount, pct }) => {
            const barColor =
              method === 'M-Pesa' ? '#1A5C3A' :
                method === 'Bank Transfer' ? '#2563EB' : '#6B7A6E';
            const badgeBg =
              method === 'M-Pesa' ? '#dcfce7' :
                method === 'Bank Transfer' ? '#dbeafe' : '#f3f4f6';
            const badgeColor =
              method === 'M-Pesa' ? '#15803d' :
                method === 'Bank Transfer' ? '#1d4ed8' : '#374151';

            return (
              <div key={method}>
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center gap-2">
                    <span
                      className="px-2 py-0.5 rounded-full text-xs"
                      style={{ backgroundColor: badgeBg, color: badgeColor, fontWeight: 500 }}
                    >
                      {method}
                    </span>
                    <span className="text-sm" style={{ color: '#1A2E1F', fontWeight: 500 }}>{pct}%</span>
                  </div>
                  <span className="text-sm" style={{ color: '#6B7A6E' }}>{fmt(amount)}</span>
                </div>
                <div className="h-2 rounded-full overflow-hidden" style={{ backgroundColor: '#EEF1EE' }}>
                  <div
                    className="h-full rounded-full transition-all"
                    style={{ width: `${pct}%`, backgroundColor: barColor }}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
