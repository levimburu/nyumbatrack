// MARKER-MAKE-KIT-INVOKED
// MARKER-MAKE-KIT-DISCOVERY-READ
import { useState } from 'react';
import { WelcomeScreen } from './components/mobile/WelcomeScreen';
import { RoleSelectionScreen } from './components/mobile/RoleSelectionScreen';
import { PinSetupScreen } from './components/mobile/PinSetupScreen';
import { PinLoginScreen } from './components/mobile/PinLoginScreen';
import { AppLayout, type Page } from './components/AppLayout';
import { PropertiesScreen } from './components/PropertiesScreen';
import { DashboardScreen } from './components/DashboardScreen';
import { TenantsScreen } from './components/TenantsScreen';
import { PaymentsScreen } from './components/PaymentsScreen';
import { ReportsScreen } from './components/ReportsScreen';

type Screen = 'welcome' | 'role' | 'pin-setup' | 'pin-login' | 'app';

function MobileFrame({ children }: { children: React.ReactNode }) {
  return (
    <div
      className="min-h-screen w-full flex items-stretch md:items-center justify-center"
      style={{ backgroundColor: '#111827' }}
    >
      <div
        className="w-full md:max-w-[400px] md:h-[820px] flex flex-col overflow-hidden"
        style={{ boxShadow: '0 30px 80px rgba(0,0,0,0.5)', borderRadius: '0' }}
      >
        <style>{`
          @media (min-width: 768px) {
            .mobile-frame-inner {
              border-radius: 32px !important;
            }
          }
        `}</style>
        <div className="mobile-frame-inner flex-1 flex flex-col overflow-hidden" style={{ height: '100%' }}>
          {children}
        </div>
      </div>
    </div>
  );
}

export default function App() {
  const [screen, setScreen] = useState<Screen>('welcome');
  const [role, setRole] = useState<'landlord' | 'agent'>('landlord');
  const [userPin, setUserPin] = useState('');
  const [userName, setUserName] = useState('');
  const [currentPage, setCurrentPage] = useState<Page>('properties');
  const [selectedPropertyId, setSelectedPropertyId] = useState('prop-1');

  const handleRoleSelect = (selectedRole: 'landlord' | 'agent') => {
    setRole(selectedRole);
    setUserName(selectedRole === 'landlord' ? 'James Mwangi' : 'Sarah Njeri');
    setScreen('pin-setup');
  };

  const handlePinSetup = (pin: string) => {
    setUserPin(pin);
    setScreen('pin-login');
  };

  const handleLogin = () => {
    setScreen('app');
    setCurrentPage('properties');
  };

  const handleSignIn = () => {
    setUserName('James Mwangi');
    setRole('landlord');
    setScreen('pin-login');
  };

  const handleSelectProperty = (id: string) => {
    setSelectedPropertyId(id);
    setCurrentPage('dashboard');
  };

  if (screen === 'welcome') {
    return (
      <MobileFrame>
        <WelcomeScreen onGetStarted={() => setScreen('role')} onSignIn={handleSignIn} />
      </MobileFrame>
    );
  }

  if (screen === 'role') {
    return (
      <MobileFrame>
        <RoleSelectionScreen onBack={() => setScreen('welcome')} onSelectRole={handleRoleSelect} />
      </MobileFrame>
    );
  }

  if (screen === 'pin-setup') {
    return (
      <MobileFrame>
        <PinSetupScreen onBack={() => setScreen('role')} onComplete={handlePinSetup} />
      </MobileFrame>
    );
  }

  if (screen === 'pin-login') {
    return (
      <MobileFrame>
        <PinLoginScreen
          userName={userName || 'James Mwangi'}
          correctPin={userPin}
          onSuccess={handleLogin}
          onBack={() => setScreen('welcome')}
        />
      </MobileFrame>
    );
  }

  return (
    <AppLayout
      currentPage={currentPage}
      onNavigate={setCurrentPage}
      selectedPropertyId={selectedPropertyId}
      onSelectProperty={handleSelectProperty}
      userName={userName || 'James Mwangi'}
      role={role}
      onSignOut={() => setScreen('welcome')}
    >
      {currentPage === 'properties' && (
        <PropertiesScreen onSelectProperty={handleSelectProperty} />
      )}
      {currentPage === 'dashboard' && (
        <DashboardScreen
          propertyId={selectedPropertyId}
          onNavigate={page => setCurrentPage(page as Page)}
        />
      )}
      {currentPage === 'tenants' && (
        <TenantsScreen propertyId={selectedPropertyId} />
      )}
      {currentPage === 'payments' && (
        <PaymentsScreen propertyId={selectedPropertyId} />
      )}
      {currentPage === 'reports' && (
        <ReportsScreen propertyId={selectedPropertyId} />
      )}
    </AppLayout>
  );
}
